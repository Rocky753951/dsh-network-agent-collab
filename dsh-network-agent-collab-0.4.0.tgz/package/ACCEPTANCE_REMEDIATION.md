# dsh-network-agent-collab 验收整改报告

- 验收角色：独立、攻击性验收官；本报告不修改源代码、不提交 Git。
- 验收时间：2026-10-05T12:36:47+08:00
- 验收目标：`/home/wei/workspace/dsh-network-agent-collab`
- 对照仓库：https://github.com/Rocky753951/dsh-network-agent-collab
- 远端 HEAD 与本地 HEAD：`5bc40117d19354c10f70d9635705869940471733`

# 验收结论

**不通过**。

LAN 的本地单元/集成测试和基础安全校验通过，但公网 IPv4 WebRTC 的主流程不能按 README/HANDOFF 描述完成：Client 生成申请包时会把 `direct://manual` 当成 WebSocket 信令地址连接，`ws` 直接抛出协议错误。因此公网 Host/Client/Grant 流程是明确失败，不是“尚未实测”。公网直连又是项目对外宣称的核心连接方式，当前版本不可发布。

## 测试环境

| 项目 | 值 |
|---|---|
| OS | Linux（当前工作区） |
| Node.js | v26.10.0 |
| npm | 11.19.1 |
| Git commit | `5bc40117d19354c10f70d9635705869940471733` |
| package 名称/版本 | `dsh-network-agent-collab` / `0.4.0`（`package.json:2-3`） |
| 目录名 | `dsh-network-agent-collab`，与包名和仓库名一致 |

## 已验证项目

| 测试项 | 方法 | 结果 | 证据 |
|---|---|---|---|
| 项目名称、版本、目录一致 | 检查目录、`package.json`、README、HANDOFF | **已验证通过** | `package.json:2-3`；`HANDOFF.md:3-13` |
| `node --check index.js` | 在目标目录执行 | **已验证通过** | 退出码 0 |
| `node --check client.js` | 在目标目录执行 | **已验证通过** | 退出码 0 |
| `npm test` | 在目标目录执行 | **已验证通过** | 26/26 pass，0 fail；覆盖输出含 DirectPeer、认证消息、配对、UI 路由 |
| 无 Agent 时拒绝启动 | 测试与静态检查 | **已验证通过** | `index.js:43` 抛出 `NETWORK_AGENT_COLLAB_REQUIRES_AGENT`；`test/index.test.js:70` |
| LAN sharedSecret 最低长度/默认值拒绝 | 测试与静态检查 | **已验证通过** | `index.js:47-48`；npm test 明确通过该用例 |
| Host/Client 初始化和持久化配对状态 | 测试 | **已验证通过（仅本机流程）** | `src/setup-state.js:76-151`；`test/setup-state.test.js:32` |
| 六位配对码 | 测试 | **已验证通过（代码级）** | `src/onboarding.js:32`；`test/onboarding.test.js:32` |
| 审批时长 `once/24h/permanent` 和权限级别 | 静态检查/单元测试覆盖配对审批 | **静态检查通过；真实 UI 操作未验证** | `src/setup-state.js:8-9,155-186`；`client.js:100-104` |
| Grant 在 Host 批准且 Client 确认后才含 room secret | 测试/静态检查 | **已验证通过（本机模拟）** | `src/setup-state.js:120-151,189-204`；`test/join-flow.test.js:15` |
| Grant/邀请篡改、过期、错误码拒绝 | 测试 | **已验证通过（代码级）** | `src/onboarding.js:66-116`；npm test 相关用例通过 |
| malformed SDP、错误 Offer/Answer 方向、错误候选者拒绝 | 测试/静态检查 | **已验证通过（模拟 PeerConnection）** | `src/direct-peer.js:29-36,80-94`；`test/direct-transport.test.js:65` |
| FederationClient HMAC、消息收发、目标过滤、一对一状态 | 测试 | **已验证通过（本机模拟 transport）** | `src/core.js:1-50,116-220`；npm test 消息收发用例通过 |
| secret/sharedSecret/Grant/私密路径泄露扫描 | 静态扫描、检查 `status()` 和日志路径 | **未发现明确泄露** | `src/setup-state.js:35-73` 对 status 做 redaction；状态文件 `0600`；但 Grant 为用户手工复制所需，未做真实浏览器日志/剪贴板审计 |
| STUN/TURN 边界说明 | 静态检查 | **已验证通过** | `src/direct-peer.js:7-10,45-48` 仅配置 STUN，未将 STUN 宣称为 TURN；README 明确说明严格 NAT/UDP 阻断会失败 |
| 过时 UI 文案 | 静态扫描 | **部分通过** | 未发现“自动检测中”；Tailscale 是当前 LAN 子选项；但 `client.js:62` 仍显示“正在连接本机 Relay”，需确认其只出现在 LAN 状态，不得用于公网误导 |
| HANDOFF 测试数字 | 文档一致性 | **明确不一致** | `HANDOFF.md:36` 写 24/24，当前实际 `npm test` 为 26/26 |

## 缺陷清单

### 1. Blocker：公网 P2P Client 在生成申请包时错误连接 `direct://manual`

- **文件/行号**：`index.js:241-246`，尤其 `index.js:245`；调用实现为 `index.js:129-136` 和 `src/pairing-signal.js:27-30`。
- **严重级别**：Blocker
- **影响发布**：是。公网 IPv4 WebRTC 主流程不能完成，0.4.0 不可宣称公网可用。
- **复现步骤**：
  1. 在 Host 和 Client 分别完成 `network=public`、`role=host/client` 初始化。
  2. Host 调用 `hostCreate()`，得到 `directOffer` 和 endpoint `direct://manual`。
  3. Client 调用 `directOffer({ offer, invitation, code })`。
  4. `directOffer()` 完成 `acceptOffer()` 和 `requestJoin()` 后，执行 `startClientSignal(result.request, invite)`（`index.js:220-221,244-245`）。
  5. `startClientPairingSignal()` 调用 `openSocket(endpoint)`，即 `new WebSocket('direct://manual')`。
  6. 可复现错误：`SyntaxError: The URL's protocol must be one of "ws:", "wss:", "http:", "https:", or "ws+unix:".`
- **实际结果**：Client 申请流程抛错；不能把申请包交给 Host，Host 无法继续 `directAnswer`/审批/Grant。
- **预期结果**：公网手工信令不应启动 WebSocket mailbox；Client 应直接返回 `{answer, request}`，由用户复制给 Host；Host 审批后的 Grant 继续通过手工复制交给 Client。
- **整改建议**：在 `directOffer()` 公网分支移除 `startClientSignal()` 调用；为 `direct://manual` 保持完全手工的 Answer/Grant 流程。为防回归，新增针对插件 API 的测试，断言 Client `directOffer()` 不实例化 WebSocket，且能返回申请包。

### 2. Major：公网直连“真实可用”没有跨设备/公网证据

- **文件/行号**：流程入口 `index.js:185-221`、`index.js:223-236`；说明 `README.md:46-71`、`HANDOFF.md:23,38-40`。
- **严重级别**：Major
- **影响发布**：是（至少阻止“公网已验收”表述）。
- **复现/验证条件**：需要两台独立设备、真实公网 IPv4、允许 UDP 的网络和至少一个可达测试时间窗；当前环境未具备这些外部条件，且缺陷 1 已在本机静态/运行时复现。
- **实际结果**：只能证明 `node-datachannel` 的模拟 transport、信令校验和单机状态机；不能证明 ICE/STUN 候选交换、DataChannel 建立、跨 NAT 消息收发或失败提示。
- **预期结果**：在至少一组真实公网 IPv4 环境完成 Offer→Answer→申请→审批→Grant→消息收发，并记录直连失败时的可理解错误；报告应分别标明公网直连与局域网/Tailscale。
- **整改建议**：先修复缺陷 1，再执行两设备矩阵：同公网、不同普通 NAT、严格 NAT/CGNAT、UDP 封锁；将“未验证”保留到证据齐全为止，不能以 `npm test` 替代。

### 3. Minor：HANDOFF 的测试数量与当前仓库不一致

- **文件/行号**：`HANDOFF.md:26-36`。
- **严重级别**：Minor
- **影响发布**：不直接阻止代码发布，但会误导验收和交接。
- **实际结果**：文档写“24/24”，本次 `npm test` 实际为 26/26。
- **预期结果**：写入本次 commit 的真实命令、测试总数和日期，或改为“以命令输出为准”。
- **整改建议**：更新为 26/26（或不固定数字），并在每次新增测试后同步 HANDOFF。

### 4. Minor：公网 UI 仍存在 Relay 语义，容易让用户误判公网传输

- **文件/行号**：`client.js:59-66`，`client.js:113-115`。
- **严重级别**：Minor
- **影响发布**：不阻止 LAN；会影响公网操作指引和故障定位。
- **实际结果**：状态字典无条件包含 `relay-connecting: 正在连接本机 Relay`，同时公网页面采用手工 Offer/Answer；当前未证明该状态永远不会在公网场景出现。
- **预期结果**：公网显示“等待 Offer/Answer/Grant”或“等待直连”，LAN 才显示 Relay；明确 STUN 仅用于候选发现，未配置 TURN。
- **整改建议**：按 `savedSetup.network` 分层生成状态文案，并增加 UI 状态测试；保留 Tailscale 仅作为 LAN 子项，移除任何“公网自动检测/自动中继”的暗示。

## 未验证项目

以下项目本次**无法验证**，不能声称“真实可用”：

1. 两台独立设备上的 DSH Host/Client 初始化、浏览器 UI 全流程和重启恢复。
2. 真实公网 IPv4 的 WebRTC Offer/Answer/DataChannel 建立、STUN 候选收集、消息/任务/激活跨设备收发。
3. 不同 NAT 类型、CGNAT、对称 NAT、UDP 被阻断、端口转发失败时的真实失败提示和超时体验。
4. 真实 Tailscale 网络上的 Relay 可达性；本次只验证代码分支和静态文案。
5. 真实 DSH GUI 注入、sidebar/main slot 生命周期、浏览器剪贴板和 UI 响应式视觉；仅执行了 JS 代码静态检查和项目测试。
6. 生产 profile 的 secret、Grant、剪贴板、浏览器 devtools、崩溃报告和日志是否泄露；本次未获取任何密钥，也未声称完成此审计。

## 发布建议

**当前版本不建议发布。**

发布前必须：

1. 修复 `index.js:245` 的 `direct://manual` WebSocket 调用，并补插件级公网手工信令回归测试。
2. 在两台独立设备和真实公网 IPv4/UDP 条件下完成并留存 Offer→Answer→申请→审批→Grant→消息收发证据；严格 NAT/UDP 阻断必须明确失败而非显示已连接。
3. 修正 `HANDOFF.md:36` 的 24/24 过时数字。
4. 将 `client.js:62` Relay 状态限制在 LAN，公网状态改为直连手工信令状态，并补 UI 文案/路由测试。
5. 修复后重新执行 `node --check index.js`、`node --check client.js`、`npm test`，并重新审计 Git 跟踪文件、发布 tgz 与源码是否一致。

在上述第 1、2 项完成前，结论不得升级为“有条件通过”。
