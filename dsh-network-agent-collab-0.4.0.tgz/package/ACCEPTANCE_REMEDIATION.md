# dsh-network-agent-collab 验收整改报告

- 验收角色：独立、攻击性验收官；本报告不修改源代码、不提交 Git。
- 验收时间：2026-10-05T12:36:47+08:00
- 验收目标：`/home/wei/workspace/dsh-network-agent-collab`
- 对照仓库：https://github.com/Rocky753951/dsh-network-agent-collab
- 远端 HEAD 与本地 HEAD：`5bc40117d19354c10f70d9635705869940471733`

# 验收结论

**有条件通过**（复核前一版 Blocker 已修复；真实跨设备公网验证仍未完成）。

LAN 的本地单元/集成测试和基础安全校验通过。前一版公网 Blocker 已由当前 commit 修复：公网 `direct://manual` 不再进入 WebSocket mailbox，Host/Client 使用手工 Offer/Answer/申请包/Grant 流程。由于当前环境仍没有第二台设备、真实公网 IPv4/NAT/UDP 条件，不能把公网直连称为“真实可用”。发布前仍必须完成跨设备实测。

## 测试环境

| 项目 | 值 |
|---|---|
| OS | Linux（当前工作区） |
| Node.js | v26.10.0 |
| npm | 11.19.1 |
| Git commit | `5bc40117d19354c10f70d9635705869940471733` |
| package 名称/版本 | `dsh-network-agent-collab` / `0.4.0`（`package.json:2-3`） |
| 目录名 | `dsh-network-agent-collab`，与包名和仓库名一致 |

## 已验证项目

| 测试项 | 方法 | 结果 | 证据 |
|---|---|---|---|
| 项目名称、版本、目录一致 | 检查目录、`package.json`、README、HANDOFF | **已验证通过** | `package.json:2-3`；`HANDOFF.md:3-13` |
| `node --check index.js` | 在目标目录执行 | **已验证通过** | 退出码 0 |
| `node --check client.js` | 在目标目录执行 | **已验证通过** | 退出码 0 |
| `npm test` | 在目标目录执行 | **已验证通过** | 26/26 pass，0 fail；覆盖输出含 DirectPeer、认证消息、配对、UI 路由 |
| 无 Agent 时拒绝启动 | 测试与静态检查 | **已验证通过** | `index.js:43` 抛出 `NETWORK_AGENT_COLLAB_REQUIRES_AGENT`；`test/index.test.js:70` |
| LAN sharedSecret 最低长度/默认值拒绝 | 测试与静态检查 | **已验证通过** | `index.js:47-48`；npm test 明确通过该用例 |
| Host/Client 初始化和持久化配对状态 | 测试 | **已验证通过（仅本机流程）** | `src/setup-state.js:76-151`；`test/setup-state.test.js:32` |
| 六位配对码 | 测试 | **已验证通过（代码级）** | `src/onboarding.js:32`；`test/onboarding.test.js:32` |
| 审批时长 `once/24h/permanent` 和权限级别 | 静态检查/单元测试覆盖配对审批 | **静态检查通过；真实 UI 操作未验证** | `src/setup-state.js:8-9,155-186`；`client.js:100-104` |
| Grant 在 Host 批准且 Client 确认后才含 room secret | 测试/静态检查 | **已验证通过（本机模拟）** | `src/setup-state.js:120-151,189-204`；`test/join-flow.test.js:15` |
| Grant/邀请篡改、过期、错误码拒绝 | 测试 | **已验证通过（代码级）** | `src/onboarding.js:66-116`；npm test 相关用例通过 |
| malformed SDP、错误 Offer/Answer 方向、错误候选者拒绝 | 测试/静态检查 | **已验证通过（模拟 PeerConnection）** | `src/direct-peer.js:29-36,80-94`；`test/direct-transport.test.js:65` |
| FederationClient HMAC、消息收发、目标过滤、一对一状态 | 测试 | **已验证通过（本机模拟 transport）** | `src/core.js:1-50,116-220`；npm test 消息收发用例通过 |
| secret/sharedSecret/Grant/私密路径泄露扫描 | 静态扫描、检查 `status()` 和日志路径 | **未发现明确泄露** | `src/setup-state.js:35-73` 对 status 做 redaction；状态文件 `0600`；但 Grant 为用户手工复制所需，未做真实浏览器日志/剪贴板审计 |
| STUN/TURN 边界说明 | 静态检查 | **已验证通过** | `src/direct-peer.js:7-10,45-48` 仅配置 STUN，未将 STUN 宣称为 TURN；README 明确说明严格 NAT/UDP 阻断会失败 |
| 过时 UI 文案 | 静态扫描 | **部分通过** | 未发现“自动检测中”；Tailscale 是当前 LAN 子选项；但 `client.js:62` 仍显示“正在连接本机 Relay”，需确认其只出现在 LAN 状态，不得用于公网误导 |
| HANDOFF 测试数字 | 文档一致性 | **明确不一致** | `HANDOFF.md:36` 写 24/24，当前实际 `npm test` 为 26/26 |

## 缺陷清单

### 1. Blocker：公网 P2P Client 在生成申请包时错误连接 `direct://manual`

- **文件/行号**：`index.js:241-246`，尤其 `index.js:245`；调用实现为 `index.js:129-136` 和 `src/pairing-signal.js:27-30`。
- **严重级别**：Blocker
- **影响发布**：是。公网 IPv4 WebRTC 主流程不能完成，0.4.0 不可宣称公网可用。
- **复现步骤**：
  1. 在 Host 和 Client 分别完成 `network=public`、`role=host/client` 初始化。
  2. Host 调用 `hostCreate()`，得到 `directOffer` 和 endpoint `direct://manual`。
  3. Client 调用 `directOffer({ offer, invitation, code })`。
  4. `directOffer()` 完成 `acceptOffer()` 和 `requestJoin()` 后，执行 `startClientSignal(result.request, invite)`（`index.js:220-221,244-245`）。
  5. `startClientPairingSignal()` 调用 `openSocket(endpoint)`，即 `new WebSocket('direct://manual')`。
  6. 可复现错误：`SyntaxError: The URL's protocol must be one of "ws:", "wss:", "http:", "https:", or "ws+unix:".`
- **实际结果**：Client 申请流程抛错；不能把申请包交给 Host，Host 无法继续 `directAnswer`/审批/Grant。
- **预期结果**：公网手工信令不应启动 WebSocket mailbox；Client 应直接返回 `{answer, request}`，由用户复制给 Host；Host 审批后的 Grant 继续通过手工复制交给 Client。
- **整改建议**：在 `directOffer()` 公网分支移除 `startClientSignal()` 调用；为 `direct://manual` 保持完全手工的 Answer/Grant 流程。为防回归，新增针对插件 API 的测试，断言 Client `directOffer()` 不实例化 WebSocket，且能返回申请包。

### 2. Major：公网直连“真实可用”没有跨设备/公网证据

- **文件/行号**：流程入口 `index.js:185-221`、`index.js:223-236`；说明 `README.md:46-71`、`HANDOFF.md:23,38-40`。
- **严重级别**：Major
- **影响发布**：是（至少阻止“公网已验收”表述）。
- **复现/验证条件**：需要两台独立设备、真实公网 IPv4、允许 UDP 的网络和至少一个可达测试时间窗；当前环境未具备这些外部条件，且缺陷 1 已在本机静态/运行时复现。
- **实际结果**：只能证明 `node-datachannel` 的模拟 transport、信令校验和单机状态机；不能证明 ICE/STUN 候选交换、DataChannel 建立、跨 NAT 消息收发或失败提示。
- **预期结果**：在至少一组真实公网 IPv4 环境完成 Offer→Answer→申请→审批→Grant→消息收发，并记录直连失败时的可理解错误；报告应分别标明公网直连与局域网/Tailscale。
- **整改建议**：先修复缺陷 1，再执行两设备矩阵：同公网、不同普通 NAT、严格 NAT/CGNAT、UDP 封锁；将“未验证”保留到证据齐全为止，不能以 `npm test` 替代。

### 3. Minor：HANDOFF 的测试数量与当前仓库不一致

- **文件/行号**：`HANDOFF.md:26-36`。
- **严重级别**：Minor
- **影响发布**：不直接阻止代码发布，但会误导验收和交接。
- **实际结果**：文档写“24/24”，本次 `npm test` 实际为 26/26。
- **预期结果**：写入本次 commit 的真实命令、测试总数和日期，或改为“以命令输出为准”。
- **整改建议**：更新为 26/26（或不固定数字），并在每次新增测试后同步 HANDOFF。

### 4. Minor：公网 UI 仍存在 Relay 语义，容易让用户误判公网传输

- **文件/行号**：`client.js:59-66`，`client.js:113-115`。
- **严重级别**：Minor
- **影响发布**：不阻止 LAN；会影响公网操作指引和故障定位。
- **实际结果**：状态字典无条件包含 `relay-connecting: 正在连接本机 Relay`，同时公网页面采用手工 Offer/Answer；当前未证明该状态永远不会在公网场景出现。
- **预期结果**：公网显示“等待 Offer/Answer/Grant”或“等待直连”，LAN 才显示 Relay；明确 STUN 仅用于候选发现，未配置 TURN。
- **整改建议**：按 `savedSetup.network` 分层生成状态文案，并增加 UI 状态测试；保留 Tailscale 仅作为 LAN 子项，移除任何“公网自动检测/自动中继”的暗示。

## 未验证项目

以下项目本次**无法验证**，不能声称“真实可用”：

1. 两台独立设备上的 DSH Host/Client 初始化、浏览器 UI 全流程和重启恢复。
2. 真实公网 IPv4 的 WebRTC Offer/Answer/DataChannel 建立、STUN 候选收集、消息/任务/激活跨设备收发。
3. 不同 NAT 类型、CGNAT、对称 NAT、UDP 被阻断、端口转发失败时的真实失败提示和超时体验。
4. 真实 Tailscale 网络上的 Relay 可达性；本次只验证代码分支和静态文案。
5. 真实 DSH GUI 注入、sidebar/main slot 生命周期、浏览器剪贴板和 UI 响应式视觉；仅执行了 JS 代码静态检查和项目测试。
6. 生产 profile 的 secret、Grant、剪贴板、浏览器 devtools、崩溃报告和日志是否泄露；本次未获取任何密钥，也未声称完成此审计。

## 发布建议

**当前版本可作有条件发布候选，但不得宣称公网直连已真实验收。**

当前已完成的整改：

1. `index.js:123-137` 对 `direct://manual` 跳过 WebSocket pairing mailbox；`index.js:213-223` 的公网 Client 流程返回本地 Answer 与申请包。
2. `client.js:63` 增加公网“等待手工交换 Offer、Answer 和 Grant；公网模式不使用 Relay”文案；`index.js:291` 按网络类型区分公网和 LAN 状态。
3. `HANDOFF.md:36` 已同步为 26/26。
4. 发布包 `dsh-network-agent-collab-0.4.0.tgz` 已随最新修复 commit 更新。

发布前仍必须：

1. 在两台独立设备和真实公网 IPv4/UDP 条件下完成并留存 Offer→Answer→申请→审批→Grant→消息收发证据；严格 NAT/UDP 阻断必须明确失败而非显示已连接。
2. 补插件级回归测试，断言 `directOffer()` 不实例化 WebSocket，且 `direct://manual` 不触发 pairing signal。
3. 重新审计真实 DSH GUI、剪贴板、日志和发布包安装流程。

## 复核记录（当前 HEAD）

- 当前 HEAD：`e68ce0349d457d8a90eafa708ed75c546dd0271d`，提交信息：`fix manual public signaling acceptance blockers`。
- `node --check index.js`：通过；`node --check client.js`：通过；`npm test`：26/26 通过。
- 已确认上一版 Blocker 的代码路径消失；但跨设备公网、真实 NAT/UDP、Tailscale 和真实 DSH GUI 仍属未验证项目。
- 本次仍未修改源代码、未提交 Git；仅更新本验收报告。

## 最新提交复核（ad373e63）

### 复核结果

当前远端 `origin/main` 与本地 `HEAD` 均为 `ad373e63b9361bba29ccd5d39d9feef016ad7368`（`simplify onboarding and auto-provision LAN secret`），包版本仍为 0.4.0。`node --check index.js`、`node --check client.js` 通过，`npm test` 26/26 通过。

### 新缺陷

1. **Major：README 与实现对公网连接方式不一致**
   - 文件：`README.md:47-49`、`README.md:69`、`index.js:204-208`。
   - README 一方面描述公网为 WebRTC 手工 Offer/Answer，另一方面又要求把 `ws://公网IP:端口` 放进邀请，并称 Host 启动“内置直连服务”；当前代码对公网 Host 固定创建 `direct://manual`，跳过 WebSocket 信令。按 README 操作会把用户引向不存在/不适用的 WebSocket 地址。
   - 预期：统一为 WebRTC 手工信令的实际步骤；删除公网 `ws://`/端口转发说明，或真正实现并测试该 WebSocket 路径。
   - 影响：公网用户按 README 无法可靠完成接入，发布前必须修复文档或实现，建议按当前代码修正文档。

2. **Minor：README 对 LAN secret 的启动要求已过时**
   - 文件：`README.md:18` 对比 `index.js:60-65`。
   - README 仍写“LAN 模式拒绝启动，除非配置……密钥”，但最新实现允许省略 `sharedSecret` 并在 profile 数据目录自动生成。会造成错误配置指导。
   - 预期：说明省略时自动生成/持久化，只有显式提供无效值才拒绝。

3. **Minor：已有 shared-secret 文件的权限不会被修正**
   - 文件：`index.js:17-25`。
   - 读取到长度合格的既有文件后立即返回，不检查或收紧权限；`writeFileSync(..., { mode: 0o600 })` 只对新建文件可靠。若该文件曾被以 0644/0666 创建，secret 仍可能被同机其他用户读取。
   - 预期：使用 `statSync` 检查 owner/mode，必要时 `chmodSync(path, 0o600)`；拒绝非普通文件/异常 owner，并增加回归测试。

### 最新发布建议

最新代码级回归测试通过，但结论仍为**有条件通过**。发布前至少修复上面的 Major 文档/实现不一致，并完成两台设备真实公网 IPv4/UDP 的 Offer→Answer→申请→审批→Grant→消息收发验证；不能以 26/26 单机测试替代跨设备验收。

## 本轮整改记录

- 已修复 README 公网流程矛盾：删除公网 `ws://`/端口转发和“内置直连服务”指引，改为实际的 Offer→Answer/申请包→审批→Grant 手工信令流程，并明确 STUN 仅用于 IPv4 ICE 候选发现。
- 已修复 README 的 LAN secret 过时说明：省略 `sharedSecret` 时自动生成并持久化本机密钥，显式无效值才拒绝启动。
- 已修复既有 `shared-secret` 权限：复用时校验普通文件和当前用户所有权，并强制收紧为 `0600`；新增回归测试。
- `HANDOFF.md` 已从 26/26 更新为 27/27；本轮 `node --check index.js`、`node --check client.js`、`npm test` 全部通过（27/27）。
- 真实跨设备公网 IPv4/NAT/UDP、Tailscale 和真实 DSH GUI 仍未验证，因此仍不得宣称公网已完成真实验收。

## 视觉复核与设计建议（dsh-design-skills / Apple minimal）

本轮只完成静态视觉审查，未取得真实 DSH GUI 截图，因此以下属于“静态检查通过/未验证”，不是视觉实机验收。

### 已观察到的优点

- `client.js:165-166` 已采用白底、近黑文字、`#f5f5f7` 辅助底、单一蓝色 accent、细边框和克制阴影，方向符合 Apple minimal。
- 公网状态文案 `client.js:62-63` 已明确“手工交换”和“不使用 Relay”，避免视觉上误导传输方式。
- Offer/邀请/Grant 使用代码块和复制按钮，信息层级比普通输入框更清晰。

### 建议工程师下一轮优化

1. **P1：恢复清晰的步骤进度，但不要恢复过重的横向步骤条**。当前移除了 `Steps` 渲染而保留 `.nac-steps` 死 CSS；建议改为单行轻量 `当前步骤 / 共 3 步` 或带 aria-current 的进度指示，避免用户在公网手工交换时迷失。
2. **P1：补真实表单标签**。`client.js:157` 的目标节点、主题、消息内容仍主要依赖 placeholder；增加可见 `<label>`、错误态和 `aria-describedby`，不能把 placeholder 当字段名。
3. **P1：统一排版层级**。当前全局基准为 `14px`，标题未形成明显 40/28/17 的层级；建议页面标题 40px/500，卡片标题 24–28px/500，正文 16–17px/1.5，避免 `font-weight:700` 的大字号。
4. **P2：增加窄屏断点和触控尺寸验证**。确认 `.nac-grid` 在 320–768px 不横向溢出，按钮最小触控高度不低于 40px，长 Offer/Answer/Grant 能折叠且不会撑破页面。
5. **P2：减少无意义空间和死样式**。当前 `.nac-card` 统一 `margin:16px`，设计规范要求组件间至少 24px；同时清理已不再渲染的 `.nac-step*` 规则，避免后续误用。
6. **P2：状态视觉需同时依赖文字和颜色**。已连接/等待/错误应有明确图标或 `role=status`，不能只靠绿/黄/红边框区分；错误提示应保留可读文本并聚焦到失败字段。

### 当前视觉结论

- 视觉方向：**静态检查基本通过**。
- 真实页面截图、浏览器剪贴板反馈、侧栏/主区 Slot 尺寸、窄屏响应式：**无法验证**。
- 在完成真实 GUI 截图与上述 P1 优化前，不建议宣称“视觉验收完成”。

## 最新版本重新审查（62778e5）

- 当前远端与本地 HEAD：`62778e550c0d6c61bd946746122ab7bba40fe62e`，提交信息：`fix acceptance documentation and secret permissions`。
- 版本仍为 0.4.0；发布包 `dsh-network-agent-collab-0.4.0.tgz` 已更新。
- `node --check index.js`、`node --check client.js`：通过；`npm test`：27/27 通过。
- README 公网流程、LAN 自动 secret 说明及既有 secret 权限问题已修复；对应静态检查和新增权限回归测试通过。
- 本次新 commit 未修改 `client.js`，此前提出的视觉 P1 项仍未落实：步骤进度、可见表单标签、排版层级与响应式断点仍需工程师处理。
- 真实 DSH GUI、截图、剪贴板、窄屏响应式、跨设备公网 IPv4/NAT/UDP 仍无法验证。

### 本次视觉整改建议（请直接交给工程师）

1. `client.js:108-116`：在三步初始化和公网手工信令流程增加轻量进度指示，使用 `aria-current="step"`，不要恢复厚重五步条。
2. `client.js:157`：为目标节点、主题、消息内容增加可见 `<label>` 和 `aria-describedby`；placeholder 只做示例。
3. `client.js:118-160` 及样式 `client.js:165-166`：建立明确字阶（页面标题约 40px/500、卡片标题 24–28px/500、正文 16–17px），移除大字号 700 字重。
4. `client.js:165-166`：增加 320–768px 响应式规则，验证 `.nac-grid` 不溢出，按钮高度至少 40px，长信令默认折叠。
5. `client.js:165`：清理未再渲染的 `.nac-steps*` 死 CSS，并将组件间距从 16px 提升到至少 24px；保持白底、近黑、单一蓝色 accent 和克制阴影。

### 当前结论

**有条件通过**：代码级检查通过，文档和密钥权限整改通过；视觉与真实跨设备能力仍不能宣称完成。

## 第二轮视觉整改记录

- 已加入轻量三步进度指示（网络/身份/确认），使用 `aria-current="step"`，避免恢复厚重步骤条。
- 已为发送协作消息的目标节点、主题、消息内容增加可见标签和辅助说明；状态区域增加 `role="status"`。
- 已建立标题层级、24px 卡片间距和至少 40px 触控按钮尺寸。
- 已加入 320–768px 响应式布局，窄屏时单列显示、长信令可换行；清理未使用的旧 `.nac-steps*` 样式。
- 本轮仍未取得真实 DSH GUI 截图，视觉实机、剪贴板、跨设备公网和 Tailscale 仍保持“未验证”。
